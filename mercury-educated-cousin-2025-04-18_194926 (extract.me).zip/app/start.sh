#!/bin/bash

# Установка переменных окружения
export TELEGRAM_TOKEN="7637689517:AAEqGUHSLqOuA-o86ZuhDkQzMzgfQP2zhZk" # <-- Вставляем НОВЫЙ токен
export LANGDOCK_API_KEY="sk-u0_Qnjw2tIsuuDPIhXhgi8zMM3y5E150FnNN5jfDd8e_abSUkFChZ85qS8jWFupLw7ZVIrrgusFVMs_YLKWp1w" # Твой Langdock API Key
export DATABASE_URL="postgresql://postgres.uwxnydocvozfnnobkyyi:E1r5ghfu@aws-0-eu-central-1.pooler.supabase.com:6543/postgres" # <-- НОВАЯ СТРОКА С ПОРТОМ 6543 И ДОМЕНОМ ПУЛЕРА

# Команда для запуска твоего бота
python3 main.py